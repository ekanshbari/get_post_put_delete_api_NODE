const express = require('express'),
  app = express(),
  bodyParser = require('body-parser');
  port = process.env.PORT || 3307;
var cors = require('cors');
app.use(cors());
app.options('*',cors());
//basic authentication
/*const basicAuth=require('express-basic-auth')
app.use(basicAuth({
	users:{'admin':'Password2$'}
}))
*/
const mysql = require('mysql');
// pool connection configurations
var pool = mysql.createPool({
	connectionLimit:100,
    host: 'localhost',
    user: 'root',
    password: 'Ekansh@1',	
    database: 'login_details'
});
 
// connect to database
//mc.connect();
exports.pool=pool;
//body parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
//Listening Port

var detailsRoutes = require('./app/route/detailsroute.js'); //importing route
detailsRoutes(app); //register the route


app.listen(port);
console.log('API server started on: ' + port);