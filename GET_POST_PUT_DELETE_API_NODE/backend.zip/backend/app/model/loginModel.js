'user strict';
var sql = require('./db.js');

var User = function(task){
    // this.user_id=task.user_id;
    this.username=task.username;
    this.password=task.password;
    // this.roles=task.roles;
};


//Validate User
User.validateUser = function (username,password, result) {
    console.log(username);
        sql.query("Select * from new_table where username = ? && password= ?", [username,password], function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    result(null, res);
              
                }
            });   
};

module.exports= User;