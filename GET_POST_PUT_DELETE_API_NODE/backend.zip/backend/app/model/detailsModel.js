'user strict';
var sql = require('./db.js');

var User = function(task){
    // this.user_id=task.user_id;
    this.id=task.id;
    this.firstName=task.firstName;
    this.lastName=task.lastName;
   
    // this.roles=task.roles;
};


//Validate User
User.create_User = function (data, result) {
    // console.log(username);
        sql.query("Insert into details_new set ?", data, function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    result(null, res);
              
                }
            });   
};

User.get_All_User = function ( result) {
    // console.log(username);
        sql.query("Select * from details_new", function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    result(null, res);
              
                }
            });   
};

User.update_details = function(data, id ,result){
    sql.query("UPDATE details_new set firstName= ?, lastName= ? where id = ?", [data.firstName, data.lastName, id], function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
      
        }
    });
}

User.delete_details = function(id ,result){
    sql.query("DELETE FROM details_new WHERE id = ?", [id], function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
      
        }
    });
}

User.get_Particular = function(id ,result){
    sql.query("Select * from details_new WHERE id = ?", [id], function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
      
        }
    });
}
module.exports= User;