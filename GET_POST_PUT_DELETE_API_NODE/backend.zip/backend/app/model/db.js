'user strict';

var mysql = require('mysql');

//local mysql db connection
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'Ekansh@1',
    database : 'login_details'
});

connection.connect(function(err) {
    if (err) throw err;
});
module.exports=connection;