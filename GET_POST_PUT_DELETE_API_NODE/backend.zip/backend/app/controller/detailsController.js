'use strict';

var User = require('../model/detailsModel.js');


//Validate User
exports.createUser = function(req, res) {
 // console.log(req.params.username);
 var data = new User(req.body);
  User.create_User(data, function(err, user) {
   //console.log(req.params.password);
    if (err)
      res.send(err);
    res.json(user);
  });
};


exports.getAllUser = function(req, res) {
    // console.log(req.params.username);
    // var data = new User(req.body);
     User.get_All_User(function(err, user) {
      //console.log(req.params.password);
       if (err)
         res.send(err);
       res.json(user);
     });
   };



   exports.updateDetails = function(req,res){
    var data = new User(req.body);

    User.update_details(data,req.params.id,function(err,user){
      
      if (err)
         res.send(err);
       res.json(user);

    });
   };

   exports.deleteDetails = function(req,res){
    var data = new User(req.body);

    User.delete_details(req.params.id,function(err,user){
      
      if (err)
         res.send(err);
       res.json(user);

    });
   };

   exports.getParticular = function(req,res){
    var data = new User(req.body);

    User.get_Particular(req.params.id,function(err,user){
      
      if (err)
         res.send(err);
       res.json(user);

    });
   };