'use strict';

var User = require('../model/loginModel.js');


//Validate User
exports.validate_a_user = function(req, res) {
 // console.log(req.params.username);
  User.validateUser(req.params.username,req.params.password, function(err, user) {
   //console.log(req.params.password);
    if (err)
      res.send(err);
    res.json(user);
  });
};