'use strict';
module.exports = function(app) {
  var UserController = require('../controller/detailsController.js');

    // app.route('/login')
    // .post(UserController.create_user)
    // .get(UserController.list_all_users);

  //   app.route('/loginUser/:username/:password')
  //   .get(UserController.validate_a_user);
  //  };
  app.route('/detailUsers')
  .post(UserController.createUser)
  .get(UserController.getAllUser);
  
  app.route('/updateUser/:id')
  .put(UserController.updateDetails)
  .delete(UserController.deleteDetails)
  .get(UserController.getParticular);
  
 };

