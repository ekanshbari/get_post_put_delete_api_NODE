let data = {
    firstName: "",
    lastName: "",
    id:0
  };

function saveToDatabase(){

  //  data.id = document.getElementById("id").value;
  //  data.lname = document.getElementById("lname").value;

    data.firstName = document.getElementById("fname").value; // Country Code from drop down
    //  var first = a.options[a.selectedIndex].value;
    
   
    data.lastName = document.getElementById("lname").value; // Zone Code from drop down
    //  var last = a.options[a.selectedIndex].value;
    
     console.log(document.getElementById("id"));
     console.log(document.getElementById("fname"));
     console.log(document.getElementById("lname"));

    //  console.log(data.id);
    //  console.log(data.fname);
    //  console.log(data.lname);

     if(data.firstName===""|| data.lastName==="" ){
        alert("All fields are required!!!!!");
      }
      else{
        var xmlhttp = new XMLHttpRequest();
        var url = "http://localhost:3307/detailUsers";
        var myArr;
        xmlhttp.onreadystatechange = function() {
          if (this.readyState === 4 && this.status === 200) {
            myArr = JSON.parse(this.responseText);
           // console.log(myArr.response);
            // if (myArr.length != 0) {
            //   alert("details created!!!!!");
            // //   window.location = "plants.html";
            //   // document.location.href="plants.html";
            // }
          }
        };
        xmlhttp.open("POST", url, true);
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.setRequestHeader(
          "Cache-Control",
          "no-cache, no-store , must-revalidate"
        );
        xmlhttp.send(JSON.stringify(data));}

}


